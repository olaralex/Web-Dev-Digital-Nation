        <!--Footer-->

        <div class="footer bg-danger p-5 text-center">
            <img src="generatia-tech.jpg" alt="">
            <div class="input-group p-4">
                    <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email">
                <div class="input-group-append">
                    <button type="submit" class="btn btn-primary">
                        Trimite
                    </button>
                </div>
            </div>
            <p>
                &copy
                <?php
                    echo date("Y");
                ?>
                Toate drepturile rezervare
            </p>
        </div>
    </body>
</html>