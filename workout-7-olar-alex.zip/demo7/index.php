<!--Include header.php pt. lucruri repetitive-->

    <?php
        require_once('includes/header.php');
    ?>

<!--Carousel-ul cu imagini-->

        <div class="carusel">
            <div id="carouselExampleIndicators" class="carousel slide" data-bs-ride="carousel">
                <div class="carousel-indicators">
                  <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
                  <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
                  <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2" aria-label="Slide 3"></button>
                </div>
                <div class="carousel-inner">
                  <div class="carousel-item active">
                    <img src="girafa.jpg" style="height: 600px; width: 100% !important;" alt="...">
                  </div>
                  <div class="carousel-item">
                    <img src="banana.jpg" style="height: 600px; width: 100% !important;" alt="...">
                  </div>
                  <div class="carousel-item">
                    <img src="rata.jpg" style="height: 600px; width: 100% !important;" alt="...">
                  </div>
                </div>
                <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
                  <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                  <span class="visually-hidden">Previous</span>
                </button>
                <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
                  <span class="carousel-control-next-icon" aria-hidden="true"></span>
                  <span class="visually-hidden">Next</span>
                </button>
              </div>
        </div>

        <!--Container-ul cu descriere-->

        <div class="container text-center p-5">
            <h1>
                Workout 5
            </h1>
            <h4>
                Foosirea a mai multor pagini
            </h4>
            <p>
                Lorem ipsum dolor sit amet consectetur adipisicing elit.
            </p>
            <a class="btn btn-dark" href="#" role="button">Inscrie-te acum!</a>
            <a class="btn btn-outline-secondary" href="despre-noi.html" role="button">Cere detalii</a>
        </div>

        <!--Bara de caracteristici-->

        <div class="caracteristici p-5 bg-light">
            <div class="row text-center align-items-center">
                <div class="col-sm-12 col-md-12 col-lg-4">
                    <img src="ro.jpg" alt="">
                    <h2>
                        Romania
                    </h2>
                    <p>
                        Lorem ipsum dolor sit amet consectetur adipisicing elit.
                    </p>
                </div>
                <div class="col-sm-12 col-md-6 col-lg-4">
                    <img src="ro.jpg" alt="">
                    <h2>
                        Romania
                    </h2>
                    <p>
                        Lorem ipsum dolor sit amet consectetur adipisicing elit.
                    </p>
                </div>
                <div class="col-sm-12 col-md-6 col-lg-4">
                    <img src="ro.jpg" alt="">
                    <h2>
                        Romania
                    </h2>
                    <p>
                        Lorem ipsum dolor sit amet consectetur adipisicing elit.
                    </p>
                </div>
            </div>
        </div>

        <!--Container Nou Cu 4 Coloane-->

        <div class="container text-center p-5">
            <div class="row border border-success">
                <div class="col-sm-6 col-lg-3 bg-light p-sm-1 p-md-2 p-lg-5 border border-success">
                    <h3>
                        <?php
                            $a = 31234;
                            echo number_format($a,0,",",".");
                        ?>
                    </h3>
                    <hr>
                    <p>
                        <?php
                            $x = 1;
                            echo "Participanti la modulul ". $x;
                        ?>
                    </p>
                </div>
                <div class="col-sm-6 col-lg-3 bg-light p-sm-1 p-md-2 p-lg-5 border border-success">
                    <h3>
                        <?php
                            $b = 42134;
                            echo number_format($b,0,",",".");
                        ?>
                    </h3>
                    <hr>
                    <p>
                        <?php
                            echo "Participanti la modulul ". ++$x;
                        ?>
                    </p>
                </div>
                <div class="col-sm-6 col-lg-3 bg-light p-sm-1 p-md-2 p-lg-5 border border-success">
                    <h3>
                        <?php
                            $c = 53124;
                            echo number_format($c,0,",",".");
                        ?>
                    </h3>
                    <hr>
                    <p>
                        <?php
                            echo "Participanti la modulul ". ++$x;
                        ?>
                    </p>
                </div>
                <div class="col-sm-6 col-lg-3 bg-light p-sm-1 p-md-2 p-lg-5 border border-success">
                    <h3>
                        <?php
                            $d = array($a , $b , $c);
                            if(array_sum($d) < 5000){
                                echo number_format(array_sum($d),0,",",".");
                            }
                        ?>
                        <strong>
                            <?php
                                if(array_sum($d) >= 5000){
                                    echo number_format(array_sum($d),0,",",".");
                                }
                            ?>
                        </strong>
                    </h3>
                    <hr>
                    <p>
                        <?php
                            echo "Participanti in total";
                        ?>
                    </p>
                </div>
            </div>
        </div>

<!--Include footer.php pt. lucruri repetitive-->

        <?php
            require_once('includes/footer.php');
        ?>