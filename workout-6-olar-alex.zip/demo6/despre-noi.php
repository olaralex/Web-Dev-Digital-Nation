<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
        <link rel="stylesheet" href="style.css">
        <title>Workout 5</title>
    </head>
    <body>
        <!--JS-->

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous"></script>

        <!--Bara de navigatii-->

        <div class="nav bg-warning p-3 d-flex justify-content-between">
            <ul>
                <li>
                    <a href="index.php">HOME</a>
                </li>
                <li>
                    <a href="despre-noi.php">DESPRE NOI</a>
                </li>
                <li>
                    <a href="contact.php">CONTACT</a>
                </li>
            </ul>
            <a href="contact.php"><img src="phone.jpg" alt=""></a>
        </div>

        <!--Container-ul cu descriere-->

        <div class="container text-center p-5">
            <h1>
                Despre Noi
            </h1>
            <div class="row p-2">
                <div class="col-sm-12 col-lg-6 p-3">
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Perferendis tempore autem expedita quam vitae facilis alias, atque quidem pariatur commodi velit est dolorem, officiis excepturi eligendi corporis nostrum sunt consequatur?
                </div>
                <div class="col-sm-12 col-lg-6 p-3">
                    Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quasi eaque assumenda quibusdam fugiat perspiciatis recusandae perferendis? Fugit magni voluptatem alias sit dignissimos libero, consequatur veniam, perferendis officia, ea cupiditate quas?
                </div>
            </div>

            <!--Collapse-->

            <p>
                <button class="btn btn-dark" type="button" data-bs-toggle="collapse" data-bs-target="#collapseExample" aria-expanded="true" aria-controls="collapseExample">
                  Citeste mai mult
                </button>
              </p>
              <div class="collapse active" id="collapseExample">
                <div class="card card-body">
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Ab ipsam tenetur molestias consequatur recusandae eaque ratione incidunt quo. Sequi eius laboriosam blanditiis vero quo, itaque doloribus deleniti officiis suscipit obcaecati?
                </div>
              </div>

        </div>

        <!--Bara cu angajatii-->

        <div class="echipa p-5 bg-light">
            <h1>
                Echipa
            </h1>
            <div class="row text-center align-items-center">
                <div class="col-sm-12 col-md-12 col-lg-4">
                    <div class="card" style="width: 18rem;">
                        <img src="bormasina.jpg" class="card-img-top" alt="...">
                        <div class="card-body">
                          <h5 class="card-title">Bormasina</h5>
                          <p class="card-text">Mereu buna la casa omului</p>
                        </div>
                      </div>
                </div>
                <div class="col-sm-12 col-md-6 col-lg-4">
                    <div class="card" style="width: 18rem;">
                        <img src="lego.jpg" class="card-img-top" alt="...">
                        <div class="card-body">
                          <h5 class="card-title">Lego</h5>
                          <p class="card-text">Perfecte in copilarie</p>
                        </div>
                      </div>
                </div>
                <div class="col-sm-12 col-md-6 col-lg-4">
                    <div class="card" style="width: 18rem;">
                        <img src="indian.jpg" class="card-img-top" alt="...">
                        <div class="card-body">
                          <h5 class="card-title">Indian</h5>
                          <p class="card-text">Te ajuta mereu cu tutoriale pe YT</p>
                        </div>
                      </div>
                </div>
            </div>
        </div>

        <!--Footer-->

        <div class="footer bg-danger p-5 text-center">
            <img src="generatia-tech.jpg" alt="">
            <div class="input-group p-4 small">
                    <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email">
                <div class="input-group-append">
                    <button type="submit" class="btn btn-primary">
                        Trimite
                    </button>
                </div>
            </div>
            <p>
                Toate drepturile rezervare &copy
            </p>
        </div>
    </body>
</html>