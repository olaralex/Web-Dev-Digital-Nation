<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
        <link rel="stylesheet" href="style.css">
        <title>Workout 5</title>
    </head>
    <body>
        <!--JS-->

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous"></script>

        <!--Bara de navigatii-->

        <div class="nav bg-warning p-3 d-flex justify-content-between">
            <ul>
                <li>
                    <a href="index.php">HOME</a>
                </li>
                <li>
                    <a href="despre-noi.php">DESPRE NOI</a>
                </li>
                <li>
                    <a href="contact.php">CONTACT</a>
                </li>
            </ul>
            <a href="contact.php"><img src="phone.jpg" alt=""></a>
        </div>

        <!--Container-ul cu datele de contact si localizare maps-->

        <div class="container p-5">
            <div>
                <div>
                    <h1 class="mb-3 font-weight-bold">
                        Contact
                    </h1>
                    <ul>
                        <li class="p-2">
                            Telefon:
                            <a href="tel:+">0712345689</a>
                        </li>
                        <li class="p-2">
                            Mail:
                            <a href="mailto:">exemplu@gmail.com</a>
                        </li>
                        <li class="p-2">
                            <address> Adresa: Str. Exemplu Nr.1 Ap.1</address>
                        </li>
                    </ul>
                    <hr>
                    <h4 class="mt-5 mb-3">
                        Front-End Developer
                    </h4>
                    <ul>
                        <li class="p-2">
                            Marcel Popescu
                        </li>
                        <li class="p-2">
                            Email:
                            <a href="mailto:">exemplu@gmail.com</a>
                        </li>
                    </ul>
                    <hr>
                    <h4 class="mt-5 mb-3">
                        Relatii cu publicul
                    </h4>
                    <ul>
                        <li class="p-2">
                            Ion Lupescu
                        </li>
                        <li class="p-2">
                            Email:
                            <a href="mailto:">exemplu@gmail.com</a>
                        </li>
                    </ul>
                    <hr>
                </div>
                <div>
                    <iframe style=" width:100%; height: 400px !important;" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2842.2834796260104!2d26.064736615039156!3d44.57076810063137!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x40b21b7a2b05826b%3A0xdab44f53518a3c3a!2s%C8%9Airiac%20Collection!5e0!3m2!1sen!2sro!4v1665512927101!5m2!1sen!2sro" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                </div>
            </div>
        </div>

        <!--Footer-->

        <div class="footer bg-danger p-5 text-center">
            <img src="generatia-tech.jpg" alt="">
            <div class="input-group p-4">
                    <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email">
                <div class="input-group-append">
                    <button type="submit" class="btn btn-primary">
                        Trimite
                    </button>
                </div>
            </div>
            <p>
                Toate drepturile rezervare &copy
            </p>
        </div>
    </body>
</html>