<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
        <link rel="stylesheet" href="style.css">
        <title>Workout 5</title>
    </head>
    <body>

        <!--JS-->

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous"></script>

        <!--Bara de navigatii-->

        <div class="nav bg-warning p-3 d-flex justify-content-between">
            <ul>
                <li>
                    <a href="index.php">HOME</a>
                </li>
                <li>
                    <a href="despre-noi.php">DESPRE NOI</a>
                </li>
                <li>
                    <a href="contact.php">CONTACT</a>
                </li>
            </ul>
            <a href="contact.php"><img src="phone.jpg" alt=""></a>
        </div>

        <!--Carousel-ul cu imagini-->

        <div class="carusel">
            <div id="carouselExampleIndicators" class="carousel slide" data-bs-ride="carousel">
                <div class="carousel-indicators">
                  <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
                  <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
                  <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2" aria-label="Slide 3"></button>
                </div>
                <div class="carousel-inner">
                  <div class="carousel-item active">
                    <img src="girafa.jpg" style="height: 600px; width: 100% !important;" alt="...">
                  </div>
                  <div class="carousel-item">
                    <img src="banana.jpg" style="height: 600px; width: 100% !important;" alt="...">
                  </div>
                  <div class="carousel-item">
                    <img src="rata.jpg" style="height: 600px; width: 100% !important;" alt="...">
                  </div>
                </div>
                <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
                  <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                  <span class="visually-hidden">Previous</span>
                </button>
                <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
                  <span class="carousel-control-next-icon" aria-hidden="true"></span>
                  <span class="visually-hidden">Next</span>
                </button>
              </div>
        </div>

        <!--Container-ul cu descriere-->

        <div class="container text-center p-5">
            <h1>
                Workout 5
            </h1>
            <h4>
                Foosirea a mai multor pagini
            </h4>
            <p>
                Lorem ipsum dolor sit amet consectetur adipisicing elit.
            </p>
            <a class="btn btn-dark" href="#" role="button">Inscrie-te acum!</a>
            <a class="btn btn-outline-secondary" href="despre-noi.html" role="button">Cere detalii</a>
        </div>

        <!--Bara de caracteristici-->

        <div class="caracteristici p-5 bg-light">
            <div class="row text-center align-items-center">
                <div class="col-sm-12 col-md-12 col-lg-4">
                    <img src="ro.jpg" alt="">
                    <h2>
                        Romania
                    </h2>
                    <p>
                        Lorem ipsum dolor sit amet consectetur adipisicing elit.
                    </p>
                </div>
                <div class="col-sm-12 col-md-6 col-lg-4">
                    <img src="ro.jpg" alt="">
                    <h2>
                        Romania
                    </h2>
                    <p>
                        Lorem ipsum dolor sit amet consectetur adipisicing elit.
                    </p>
                </div>
                <div class="col-sm-12 col-md-6 col-lg-4">
                    <img src="ro.jpg" alt="">
                    <h2>
                        Romania
                    </h2>
                    <p>
                        Lorem ipsum dolor sit amet consectetur adipisicing elit.
                    </p>
                </div>
            </div>
        </div>

        <!--Container Nou Cu 4 Coloane-->

        <div class="container text-center p-5">
            <div class="row border border-success">
                <div class="col-sm-6 col-lg-3 bg-light p-sm-1 p-md-2 p-lg-5 border border-success">
                    <h3>
                        <?php
                            $a = 1234;
                            echo $a;
                        ?>
                    </h3>
                    <hr>
                    <p>
                        <?php
                            $x = 1;
                            echo "Participanti la modulul ". $x;
                        ?>
                    </p>
                </div>
                <div class="col-sm-6 col-lg-3 bg-light p-sm-1 p-md-2 p-lg-5 border border-success">
                    <h3>
                        <?php
                            $b = 2134;
                            echo $b;
                        ?>
                    </h3>
                    <hr>
                    <p>
                        <?php
                            echo "Participanti la modulul ". ++$x;
                        ?>
                    </p>
                </div>
                <div class="col-sm-6 col-lg-3 bg-light p-sm-1 p-md-2 p-lg-5 border border-success">
                    <h3>
                        <?php
                            $c = 3124;
                            echo $c;
                        ?>
                    </h3>
                    <hr>
                    <p>
                        <?php
                            echo "Participanti la modulul ". ++$x;
                        ?>
                    </p>
                </div>
                <div class="col-sm-6 col-lg-3 bg-light p-sm-1 p-md-2 p-lg-5 border border-success">
                    <h3>
                        <?php
                            $d = $a + $b + $c;
                            echo $d;
                        ?>
                    </h3>
                    <hr>
                    <p>
                        <?php
                            echo "Participanti in total";
                        ?>
                    </p>
                </div>
            </div>
        </div>

        <!--Footer-->

        <div class="footer bg-danger p-5 text-center">
            <img src="generatia-tech.jpg" alt="">
            <div class="input-group p-4">
                    <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email">
                <div class="input-group-append">
                    <button type="submit" class="btn btn-primary">
                        Trimite
                    </button>
                </div>
            </div>
            <p>
                Toate drepturile rezervare &copy
            </p>
        </div>
    </body>
</html>